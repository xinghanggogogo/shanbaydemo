# -*- coding: utf-8 -*－
'''
import datetime
import time
ltime=time.localtime(1395025933)
print type(ltime)

print timeStr
print type(timeStr)
'''



# s = '邢航'
# print '邢航_%s' % (s)




# import re
# p = re.compile('邢航')
# print p.match('邢航ggg')
# if (p.match('邢航ggg')!=None):
#     print "####"
#



#
# import re
# import datetime
# import string
# def getYesterday():
#     today=datetime.date.today()
#     oneday=datetime.timedelta(days=1)
#     yesterday=today-oneday
#     return str(yesterday)
#



#
# datetime = '昨天 11:11'
# p = re.compile('昨天')
# if (p.match('datetime')!= None):
#     print '*******************************'
#     strdatetime = str(datetime)
#     time1=strdatetime.split(srt= ' ',num=string.count(str))[-1]
#     yesterday = getYesterday()
#     datetime = yesterday + time1
#     print datetime
# else:
#     pass
#
# test = ''
# if re.match(r'正则表达式', test):
#     print('ok')
# else:
#     print('failed')



import datetime

import time

# def getYesterday():
#     today=datetime.date.today()
#     print type(today)
#     oneday=datetime.timedelta(days=1)
#     print type(oneday)
#     yesterday=today-oneday
#     return str(yesterday)
# print getYesterday()
#
# print datetime.datetime.now()
# print type(datetime.datetime.now())




# import re
# s = 'www.asdf.com/1234'
# m = re.findall(r'\w[0-9]+',s)
# print m[0]



# import  string
# s = 'bbbb,a,cccc'
# print s.split('a')

#
# m = "abcd"
# m = m[:-2]
# print m

#
# import re
# a = '12:23'
# if re.match(r'\d{2}:\d{2}',a):
#     print "yes"


#
# import time
# import string
# from urllib import urlencode,quote
# timestr = time.strftime('%Y-%m-%d %X',time.localtime(time.time()))
# print timestr
# print type(timestr.split('-')[2])


# import re
# s = '2016-5-11 10:21:23'
# match = re.match('2016-5-11',s)
# if match:
#     print 'ok'
#     print  match.group()  #匹配输出。
# else:
#     print 'not ok'


# i = 2
# if i==3 or i==2:
#     print "yes"

# import time
# import datetime
# def getday(day):
#     today=datetime.date.today()
#     delday=datetime.timedelta(days=day)
#     datetime1=today-delday
#     return str(datetime1)
#
# date = getday(3)
# print date



# import time
# timestr = time.strftime('%Y-%m-%d %X',time.localtime(time.time()))
# print timestr[11:19]


#冒泡排序
# a = list(raw_input('please input a list:'))
# def bubblesort(list):
#     length = len(list)
#     print length
#     for i in range(0,length-1):
#         flag = False
#         for j in range(length-1,i,-1):
#             if (list[j]<list[j-1]):
#                 list[j-1],list[j] = list[j],list[j-1]
#                 flag = True
#         if flag==False:
#             exit()
#
# bubblesort(a)
# print a


#取出一个字符串中的所有的数字。
s = "发表于：2013-06-04"
datetime = filter(lambda x:x.isdigit(),s)
print datetime
